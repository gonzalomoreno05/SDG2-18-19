#ifndef KBHITh
#define KBHITh

int kbhit(void);
int kbread(void);

#endif 

